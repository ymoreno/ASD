CREATE TABLE public.contact
(
    id integer NOT NULL DEFAULT nextval('contact_id_seq'::regclass),
    first_name character varying(35) COLLATE pg_catalog."default" NOT NULL,
    last_name character varying(35) COLLATE pg_catalog."default" NOT NULL,
    phone_number character varying(12) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT contact_pkey PRIMARY KEY (id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.contact
    OWNER to postgres;

GRANT ALL ON TABLE public.contact TO livevox;

GRANT ALL ON TABLE public.contact TO postgres;