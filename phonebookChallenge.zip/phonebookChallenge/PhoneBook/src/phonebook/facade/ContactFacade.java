package phonebook.facade;

import java.sql.SQLException;
import java.util.List;

import phonebook.bo.ContactBO;
import phonebook.vo.ContactVO;

public class ContactFacade {

	public void add(ContactVO vo){
		ContactBO bo = new ContactBO();
		try {
			bo.addContact(vo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<ContactVO> search(ContactVO vo){
		ContactBO bo = new ContactBO();
		try {
			return bo.searchContact(vo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public List<ContactVO> list(){
		ContactBO bo = new ContactBO();
		try {
			return bo.listContacts();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
