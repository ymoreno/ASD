package phonebook.databaseutility;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnector {

	private static Connection con = null;

	@SuppressWarnings("unused")
	public static Connection getConnection() {
		if (con == null) {
			String urlDatabase = "jdbc:postgresql://localhost:5432/phonebook";
			try {
				Class.forName("org.postgresql.Driver");
				con = DriverManager.getConnection(urlDatabase, "livevox", "l1v3v0x");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return con;
	}
}