package phonebook.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import phonebook.facade.ContactFacade;
import phonebook.vo.ContactVO;

@WebServlet("/contactServlet")
public class ContactController extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private ContactFacade facade;

	public ContactController() {
		super();
		facade = new ContactFacade();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<ContactVO> lista = facade.list();
		request.setAttribute("contacts", lista);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if(request.getParameter("lastNameSearch")!=null){
			ContactVO vo = new ContactVO();
			vo.setLastName(request.getParameter("lastNameSearch"));
			List<ContactVO> lista = facade.search(vo);
			request.setAttribute("contacts", lista);
		}else{
		ContactVO vo = new ContactVO();
		vo.setFirstName(request.getParameter("firstName"));
		vo.setLastName(request.getParameter("lastName"));
		vo.setPhoneNumber(request.getParameter("phoneNumber"));
		facade.add(vo);
		List<ContactVO> lista = facade.list();
		request.setAttribute("contacts", lista);
		}
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/index.jsp");
		dispatcher.forward(request, response);
	}

}
