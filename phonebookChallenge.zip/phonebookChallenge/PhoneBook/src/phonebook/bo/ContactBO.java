package phonebook.bo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.healthmarketscience.sqlbuilder.SelectQuery;

import phonebook.databaseutility.DatabaseConnector;
import phonebook.vo.ContactVO;

public class ContactBO {

	public void addContact(ContactVO contacto) throws SQLException {
		Connection c = DatabaseConnector.getConnection();

		String insertTableSQL = "INSERT INTO contact" + "(first_name, last_name, phone_number) VALUES" + "(?,?,?)";
		PreparedStatement preparedStatement = c.prepareStatement(insertTableSQL);
		preparedStatement.setString(1, contacto.getFirstName());
		preparedStatement.setString(2, contacto.getLastName());
		preparedStatement.setString(3, contacto.getPhoneNumber());
		// execute insert SQL stetement
		preparedStatement.executeUpdate();
	}

	public List<ContactVO> searchContact(ContactVO criteria) throws SQLException {
		Connection c = DatabaseConnector.getConnection();
		List<ContactVO> listaContactos = new ArrayList<>();
		List<String> params = new ArrayList<String>();

		StringBuffer sB = new StringBuffer("SELECT id, first_name, last_name, phone_number from contact where 1=1 ");

		if (criteria.getFirstName() != null && !criteria.getFirstName().isEmpty()) {
			sB.append("and first_name like ? ");
			params.add(criteria.getFirstName() + "%");
		}
		if (criteria.getLastName() != null && !criteria.getLastName().isEmpty()) {
			sB.append("and last_name like ? ");
			params.add(criteria.getLastName() + "%");
		}
		if (criteria.getPhoneNumber() != null && !criteria.getPhoneNumber().isEmpty()) {
			sB.append("and phone_number like ? ");
			params.add(criteria.getPhoneNumber() + "%");
		}

		String selectTableSQL = sB.toString();
		PreparedStatement preparedStatement = c.prepareStatement(selectTableSQL);
		preparedStatement.setString(1, criteria.getLastName());
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			ContactVO contact = new ContactVO();
			contact.setId(rs.getLong("id"));
			contact.setFirstName(rs.getString("first_name"));
			contact.setLastName(rs.getString("last_name"));
			contact.setPhoneNumber(rs.getString("phone_number"));
			listaContactos.add(contact);
		}
		return listaContactos;
	}

	public List<ContactVO> listContacts() throws SQLException {
		Connection c = DatabaseConnector.getConnection();
		List<ContactVO> listaContactos = new ArrayList<>();

		String selectTableSQL = "SELECT id, first_name, last_name, phone_number from contact";
		Statement statement = c.createStatement();
		ResultSet rs = statement.executeQuery(selectTableSQL);
		while (rs.next()) {
			ContactVO contact = new ContactVO();
			contact.setId(rs.getLong("id"));
			contact.setFirstName(rs.getString("first_name"));
			contact.setLastName(rs.getString("last_name"));
			contact.setPhoneNumber(rs.getString("phone_number"));
			listaContactos.add(contact);
		}

		return listaContactos;
	}

}
